using System;
using System.Collections.Generic;
using System.Text;

namespace Help
{
    class Stub
    {
        public static int Main(string[] args)
        {
            return 0;
        }
    }
}
