Please read dotnet_2_0/readme.txt.
